var searchData=
[
  ['setfrequencymode',['setFrequencyMode',['../classOculusDriver.html#ad0533517d029785c56329730082962cd',1,'OculusDriver']]],
  ['setgain',['setGain',['../classOculusDriver.html#ad2c9b1948147a420a4669bb21ccead5f',1,'OculusDriver']]],
  ['setgamma',['setGamma',['../classOculusDriver.html#a3ce9cbc386f6617e80ef10036f3c6802',1,'OculusDriver']]],
  ['setoculusipaddress',['setOculusIpAddress',['../classOculusDriver.html#a31d7bd517c4774d307192bfbaeeced2d',1,'OculusDriver']]],
  ['shutdown',['shutdown',['../classOculusDriver.html#a4687f949c3547241c317504856b76201',1,'OculusDriver']]],
  ['stop',['stop',['../classOculusDriver.html#a76f26d85e497e941a59b6f5d6bca957f',1,'OculusDriver']]]
];
