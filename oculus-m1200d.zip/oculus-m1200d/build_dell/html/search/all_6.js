var searchData=
[
  ['getdatadepth',['getDataDepth',['../classOculusDriver.html#aed562fa0262b63b40dfa9ae6c72264e2',1,'OculusDriver']]],
  ['getfrequencymodeflag',['getFrequencyModeFlag',['../classOculusDriver.html#a0aaac35eab767a90be0b1d789d2a00b4',1,'OculusDriver']]],
  ['getfrequencymodestring',['getFrequencyModeString',['../classOculusDriver.html#aae6f2baf59064b855bebbd4bcd8ea169',1,'OculusDriver']]],
  ['getgain',['getGain',['../classOculusDriver.html#a38aff7fbcd3629ae98a534fb3d08fcb3',1,'OculusDriver']]],
  ['getgamma',['getGamma',['../classOculusDriver.html#a82843006c51f2f444f0c945ff48f23f5',1,'OculusDriver']]],
  ['getlatestdatapacket',['getLatestDataPacket',['../classOculusDriver.html#ad2c11be70c8769b5a2e1701fece192f5',1,'OculusDriver']]],
  ['getoculusipaddress',['getOculusIpAddress',['../classOculusDriver.html#a15bd2960efb1f5e93a994377cea09139',1,'OculusDriver']]],
  ['getoculusmacaddress',['getOculusMacAddress',['../classOculusDriver.html#a3006d773064e1707396a9ec2f7e4eae0',1,'OculusDriver']]],
  ['getpingrateflag',['getPingRateFlag',['../classOculusDriver.html#a3c5fb2a81d6f9366b82c247b682b890e',1,'OculusDriver']]],
  ['getpingratehz',['getPingRateHz',['../classOculusDriver.html#a6dfc4d095d04072851ce4c2c77a0d4bc',1,'OculusDriver']]],
  ['getrangeupperlimit',['getRangeUpperLimit',['../classOculusDriver.html#a385145e8753891fc07f2e736a12be6d1',1,'OculusDriver']]]
];
