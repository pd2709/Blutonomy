var searchData=
[
  ['kdata16bit',['kData16Bit',['../classOculusDriver.html#a9607961ff55665a91e54ae9cce507fd3a8422bbae344c7a2c942edee6de50a0bc',1,'OculusDriver']]],
  ['kdata24bit',['kData24Bit',['../classOculusDriver.html#a9607961ff55665a91e54ae9cce507fd3a37114c3aa4fd064e76f1dca77f15e7c9',1,'OculusDriver']]],
  ['kdata32bit',['kData32Bit',['../classOculusDriver.html#a9607961ff55665a91e54ae9cce507fd3ae69687e085a78b9915ef2f816acb4e9b',1,'OculusDriver']]],
  ['kdata8bit',['kData8Bit',['../classOculusDriver.html#a9607961ff55665a91e54ae9cce507fd3a732407b434099675d774f9d51f637ae9',1,'OculusDriver']]],
  ['kdummy',['kDummy',['../classOculusDriver.html#af007df11cf27d60b2471daefd6097f11abab99f9c5ed808f394addc60953ce868',1,'OculusDriver']]],
  ['khigh',['kHigh',['../classOculusDriver.html#a4704ef8cea386fdb04111f798480283eaa022f15e910eb36278094efb6e808a07',1,'OculusDriver']]],
  ['kinitialisation',['kInitialisation',['../classOculusDriver.html#af007df11cf27d60b2471daefd6097f11a8c2bbf45b98c4889b24dd0398175b12d',1,'OculusDriver']]],
  ['klow',['kLow',['../classOculusDriver.html#a4704ef8cea386fdb04111f798480283eacd8fe42741a3bbc973bbf1d404afeff4',1,'OculusDriver']]],
  ['koriginal',['kOriginal',['../classOculusDriver.html#a00cc3dbe7ea6b27895a05464ef077ca9ac5871190ae0131a888fd2bf5ee179531',1,'OculusDriver']]],
  ['kpingresult',['kPingResult',['../classOculusDriver.html#af007df11cf27d60b2471daefd6097f11a21e09258fbb23d34becf85fb7460a775',1,'OculusDriver']]],
  ['ksimplefire',['kSimpleFire',['../classOculusDriver.html#af007df11cf27d60b2471daefd6097f11ae9b1796818819bc91f56ce8791b464d4',1,'OculusDriver']]],
  ['ksimplepingresult',['kSimplePingResult',['../classOculusDriver.html#af007df11cf27d60b2471daefd6097f11a24c7d06ad8276287e4f4ddb36259a253',1,'OculusDriver']]],
  ['kstatus',['kStatus',['../classOculusDriver.html#af007df11cf27d60b2471daefd6097f11a34f9dab6492af9ec6c83aa9b8345c7b8',1,'OculusDriver']]],
  ['kuserconfig',['kUserConfig',['../classOculusDriver.html#af007df11cf27d60b2471daefd6097f11a7fa41e2796cd66bc8d4cf5d6d27d401c',1,'OculusDriver']]],
  ['kversion2',['kVersion2',['../classOculusDriver.html#a00cc3dbe7ea6b27895a05464ef077ca9a15ffbbfc7eb261d13423816d275c98c4',1,'OculusDriver']]]
];
