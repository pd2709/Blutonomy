var searchData=
[
  ['simple_5fping_5fresult',['simple_ping_result',['../structOculusDriver_1_1DataPacket.html#ae69a4150d08f3bbe1e6bba90393e7390',1,'OculusDriver::DataPacket']]]
];
