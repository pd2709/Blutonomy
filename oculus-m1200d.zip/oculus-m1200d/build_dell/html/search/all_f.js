var searchData=
[
  ['unpacked_5f16_5fbit_5fdata',['unpacked_16_bit_data',['../structOculusDriver_1_1DataPacket.html#a5b3b9d086f9e4803d24680dbee7cb42e',1,'OculusDriver::DataPacket']]],
  ['unpacked_5f32_5fbit_5fdata',['unpacked_32_bit_data',['../structOculusDriver_1_1DataPacket.html#a8ce32e0ba23005ae47334263234e81fc',1,'OculusDriver::DataPacket']]],
  ['unpacked_5f8_5fbit_5fdata',['unpacked_8_bit_data',['../structOculusDriver_1_1DataPacket.html#ae8a95258c310b6076053297e9e1f964a',1,'OculusDriver::DataPacket']]],
  ['userconfig',['UserConfig',['../structOculusDriver_1_1UserConfig.html',1,'OculusDriver']]]
];
